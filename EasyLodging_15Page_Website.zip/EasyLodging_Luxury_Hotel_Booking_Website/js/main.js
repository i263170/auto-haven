function isInPagesFolder() {
  return window.location.pathname.includes('/pages/');
}

function routePath(target) {
  const inSub = isInPagesFolder();
  if (target === 'home') return inSub ? '../index.html' : 'index.html';
  return inSub ? `${target}.html` : `pages/${target}.html`;
}

function showToast(message, isError = false) {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    container.setAttribute('aria-live', 'polite');
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast ${isError ? 'toast--error' : ''}`;
  toast.innerHTML = `
    <span>${message}</span>
    <button type="button" aria-label="Dismiss" style="background:none;border:none;color:inherit;font-weight:700;">✕</button>
  `;
  toast.querySelector('button').addEventListener('click', () => toast.remove());
  container.appendChild(toast);
  setTimeout(() => {
    if (toast.parentElement) toast.remove();
  }, 4200);
}

// Inline Sign In / Traveler Account Modal available on every page
function openAuthModal() {
  ensureSeededState();
  const profile = readStorage(EL_STORAGE_KEYS.PROFILE, EL_SEED_DATA.defaultProfile);
  let backdrop = document.getElementById('el-auth-modal');
  if (!backdrop) {
    backdrop = document.createElement('div');
    backdrop.id = 'el-auth-modal';
    backdrop.className = 'el-modal-backdrop';
    backdrop.setAttribute('role', 'dialog');
    backdrop.setAttribute('aria-modal', 'true');
    backdrop.setAttribute('aria-label', 'Guest Sign In & Account');
    document.body.appendChild(backdrop);
  }

  backdrop.innerHTML = `
    <div class="el-modal-card">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.75rem;">
        <div>
          <div class="section-eyebrow" style="margin-bottom:0.15rem;">EasyLodging Guest Pass</div>
          <h2 style="margin:0;font-family:var(--font-serif);font-size:1.35rem;">
            ${profile.signedIn ? 'Signed In Traveler' : 'Sign In to EasyLodging'}
          </h2>
        </div>
        <button type="button" class="icon-btn" id="auth-close-btn" aria-label="Close modal">✕</button>
      </div>

      ${
        profile.signedIn
          ? `<div style="background:var(--bg-ivory);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:0.9rem;margin-bottom:1rem;">
               <div style="font-weight:700;">${profile.fullName}</div>
               <div style="font-size:0.86rem;color:var(--ink-secondary);">${profile.email} · Currency: ${profile.currency || 'PKR'}</div>
             </div>
             <div style="display:flex;gap:0.65rem;flex-wrap:wrap;">
               <a href="${routePath('traveler-profile')}" class="btn btn--primary btn--sm" style="flex:1;">Open Profile</a>
               <a href="${routePath('my-bookings')}" class="btn btn--outline btn--sm" style="flex:1;">My Trips</a>
               <button type="button" class="btn btn--outline btn--sm" id="auth-signout-btn">Sign Out</button>
             </div>`
          : `<form id="quick-signin-form" novalidate>
               <div style="margin-bottom:0.8rem;">
                 <label style="display:block;font-size:0.84rem;font-weight:600;margin-bottom:0.3rem;">Full Name</label>
                 <input type="text" id="qs-name" class="form-control" value="${profile.fullName || 'Ayesha Siddiqui'}" required />
               </div>
               <div style="margin-bottom:1rem;">
                 <label style="display:block;font-size:0.84rem;font-weight:600;margin-bottom:0.3rem;">Email Address</label>
                 <input type="email" id="qs-email" class="form-control" value="${profile.email || 'ayesha.siddiqui@example.pk'}" required />
               </div>
               <div id="qs-error" class="form-error" style="margin-bottom:0.75rem;"></div>
               <button type="submit" class="btn btn--primary btn--full">Continue as Traveler</button>
             </form>`
      }
    </div>
  `;

  backdrop.classList.add('is-open');
  backdrop.querySelector('#auth-close-btn').addEventListener('click', () => backdrop.classList.remove('is-open'));
  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) backdrop.classList.remove('is-open');
  });

  const signOutBtn = backdrop.querySelector('#auth-signout-btn');
  if (signOutBtn) {
    signOutBtn.addEventListener('click', () => {
      const updated = { ...profile, signedIn: false };
      writeStorage(EL_STORAGE_KEYS.PROFILE, updated);
      backdrop.classList.remove('is-open');
      showToast('Signed out of guest session.');
      renderHeader(document.body.dataset.navKey || 'home', document.body.dataset.lightHeader === '1', document.body.dataset.hostMode === '1');
    });
  }

  const quickForm = backdrop.querySelector('#quick-signin-form');
  if (quickForm) {
    quickForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const nameVal = backdrop.querySelector('#qs-name').value.trim();
      const emailVal = backdrop.querySelector('#qs-email').value.trim();
      const errEl = backdrop.querySelector('#qs-error');
      if (!nameVal || !emailVal || !emailVal.includes('@')) {
        errEl.textContent = 'Please enter a valid name and email address.';
        return;
      }
      const updated = { ...profile, signedIn: true, fullName: nameVal, email: emailVal, currency: 'PKR' };
      writeStorage(EL_STORAGE_KEYS.PROFILE, updated);
      backdrop.classList.remove('is-open');
      showToast(`Welcome back, ${nameVal}!`);
      renderHeader(document.body.dataset.navKey || 'home', document.body.dataset.lightHeader === '1', document.body.dataset.hostMode === '1');
    });
  }
}

function renderHeader(activeKey = 'home', lightTheme = false, hostMode = false) {
  const headerEl = document.getElementById('site-header');
  if (!headerEl) return;

  document.body.dataset.navKey = activeKey;
  document.body.dataset.lightHeader = lightTheme ? '1' : '0';
  document.body.dataset.hostMode = hostMode ? '1' : '0';

  ensureSeededState();
  const profile = readStorage(EL_STORAGE_KEYS.PROFILE, EL_SEED_DATA.defaultProfile);

  headerEl.className = `site-header ${lightTheme ? 'site-header--light' : ''}`;

  const navItems = hostMode
    ? [
        { key: 'host-dashboard', label: 'Dashboard', href: routePath('host-dashboard') },
        { key: 'add-edit-listing', label: 'Listings', href: routePath('add-edit-listing') },
        { key: 'my-bookings', label: 'Bookings', href: routePath('my-bookings') },
        { key: 'help-center', label: 'Help', href: routePath('help-center') }
      ]
    : [
        { key: 'home', label: 'Home', href: routePath('home') },
        { key: 'explore-cities', label: 'Explore Cities', href: routePath('explore-cities') },
        { key: 'my-bookings', label: 'Trips', href: routePath('my-bookings') }
      ];

  const authLabel = profile.signedIn ? `${profile.fullName.split(' ')[0]} · Account` : 'Sign in';

  headerEl.innerHTML = `
    <div class="header-inner">
      <a href="${routePath('home')}" class="brand-mark" aria-label="EasyLodging Home">
        <span class="brand-mark__emblem">EL</span>
        <span>
          ${hostMode ? 'EasyLodging Host' : 'EasyLodging'}
          <span class="brand-mark__sub">${hostMode ? 'Partner Portal' : 'Luxury Stays · PKR'}</span>
        </span>
      </a>

      <nav class="desktop-nav" aria-label="Primary Navigation">
        ${navItems
          .map(
            (item) => `
          <a href="${item.href}" class="nav-link ${activeKey === item.key ? 'is-active' : ''}">
            ${item.label}
          </a>
        `
          )
          .join('')}
        <button type="button" id="header-auth-trigger" class="nav-cta-pill ${activeKey === 'traveler-profile' ? 'is-active' : ''}">
          ${authLabel}
        </button>
      </nav>

      <div class="mobile-header-actions">
        <button type="button" id="mobile-auth-trigger" class="icon-btn" aria-label="Account sign in">👤</button>
        <button type="button" class="icon-btn" id="open-mobile-drawer" aria-label="Open menu">☰</button>
      </div>
    </div>
  `;

  document.getElementById('header-auth-trigger')?.addEventListener('click', openAuthModal);
  document.getElementById('mobile-auth-trigger')?.addEventListener('click', openAuthModal);
  setupMobileDrawer();
}

function setupMobileDrawer() {
  let drawer = document.getElementById('mobile-drawer');
  if (!drawer) {
    drawer = document.createElement('div');
    drawer.id = 'mobile-drawer';
    drawer.className = 'mobile-drawer';
    drawer.innerHTML = `
      <div class="mobile-drawer__panel" role="dialog" aria-label="Mobile Menu">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.4rem;">
          <strong>EasyLodging Menu</strong>
          <button type="button" class="icon-btn" id="close-mobile-drawer" aria-label="Close menu">✕</button>
        </div>
        <a class="mobile-drawer__link" href="${routePath('home')}">Home <span>→</span></a>
        <a class="mobile-drawer__link" href="${routePath('explore-cities')}">Explore Cities <span>→</span></a>
        <a class="mobile-drawer__link" href="${routePath('search-results')}">Search Results <span>→</span></a>
        <a class="mobile-drawer__link" href="${routePath('my-bookings')}">My Bookings <span>→</span></a>
        <a class="mobile-drawer__link" href="${routePath('saved-stays')}">Saved Stays <span>→</span></a>
        <a class="mobile-drawer__link" href="${routePath('traveler-profile')}">Traveler Profile <span>→</span></a>
        <a class="mobile-drawer__link" href="${routePath('reviews-ratings')}">Reviews & Ratings <span>→</span></a>
        <a class="mobile-drawer__link" href="${routePath('host-dashboard')}">Host Dashboard <span>→</span></a>
        <a class="mobile-drawer__link" href="${routePath('add-edit-listing')}">Add / Edit Listing <span>→</span></a>
        <a class="mobile-drawer__link" href="${routePath('help-center')}">Help Center & Policies <span>→</span></a>
      </div>
    `;
    document.body.appendChild(drawer);
  }

  document.getElementById('open-mobile-drawer')?.addEventListener('click', () => drawer.classList.add('is-open'));
  document.getElementById('close-mobile-drawer')?.addEventListener('click', () => drawer.classList.remove('is-open'));
  drawer.addEventListener('click', (e) => {
    if (e.target === drawer) drawer.classList.remove('is-open');
  });
}

function renderMobileBottomNav(activeTab = 'home') {
  let nav = document.getElementById('mobile-bottom-nav');
  if (!nav) {
    nav = document.createElement('nav');
    nav.id = 'mobile-bottom-nav';
    nav.className = 'mobile-bottom-nav';
    nav.setAttribute('aria-label', 'Mobile Bottom Navigation');
    document.body.appendChild(nav);
  }

  const tabs = [
    { key: 'home', label: 'Home', icon: '⌂', href: routePath('home') },
    { key: 'explore', label: 'Explore', icon: '❖', href: routePath('explore-cities') },
    { key: 'search', label: 'Search', icon: '⌕', href: routePath('search-results') },
    { key: 'trips', label: 'Trips', icon: '◫', href: routePath('my-bookings') },
    { key: 'profile', label: 'Profile', icon: '◯', href: routePath('traveler-profile') }
  ];

  nav.innerHTML = tabs
    .map(
      (t) => `
    <a href="${t.href}" class="mobile-bottom-nav__item ${activeTab === t.key ? 'is-active' : ''}">
      <span aria-hidden="true">${t.icon}</span>
      <span>${t.label}</span>
    </a>
  `
    )
    .join('');
}

function renderFooter() {
  const footerEl = document.getElementById('site-footer');
  if (!footerEl) return;

  footerEl.className = 'site-footer';
  footerEl.innerHTML = `
    <div class="container">
      <div class="disclosure-note">
        <strong>Photography & Demo Notice:</strong> Interior photographs include Unsplash photography (Rod Long &amp; Frames For Your Heart) and luxury architectural scenes generated for visual presentation. All PKR prices and reservations are simulated locally in <code>localStorage</code> with no real payment gateway connected.
      </div>

      <div class="footer-grid">
        <div>
          <div class="brand-mark" style="margin-bottom:0.65rem;">
            <span class="brand-mark__emblem">EL</span>
            <span>EasyLodging</span>
          </div>
          <p class="section-subtitle" style="font-size:0.88rem;">
            Curated luxury stays, mountain sanctuaries, and heritage hotels across Pakistan—priced in PKR.
          </p>
        </div>

        <div>
          <h3 class="footer-heading">Discover</h3>
          <ul class="footer-links">
            <li><a href="${routePath('home')}">Home</a></li>
            <li><a href="${routePath('explore-cities')}">Explore Cities</a></li>
            <li><a href="${routePath('search-results')}">Search Results</a></li>
            <li><a href="${routePath('reviews-ratings')}">Reviews & Ratings</a></li>
          </ul>
        </div>

        <div>
          <h3 class="footer-heading">Guest & Host</h3>
          <ul class="footer-links">
            <li><a href="${routePath('my-bookings')}">My Bookings</a></li>
            <li><a href="${routePath('saved-stays')}">Saved Stays</a></li>
            <li><a href="${routePath('traveler-profile')}">Traveler Profile</a></li>
            <li><a href="${routePath('host-dashboard')}">Host Dashboard</a></li>
          </ul>
        </div>

        <div>
          <h3 class="footer-heading">Support</h3>
          <ul class="footer-links">
            <li><a href="${routePath('add-edit-listing')}">Add / Edit Listing</a></li>
            <li><a href="${routePath('help-center')}">Help Center & Policies</a></li>
            <li><a href="${routePath('checkout')}">Checkout Flow</a></li>
          </ul>
        </div>
      </div>

      <div class="footer-bottom">
        <span>© 2026 EasyLodging. Luxury Stays · PKR.</span>
        <span>Desktop (1440px) &amp; Mobile (375px) Responsive</span>
      </div>
    </div>
  `;
}

const Lightbox = {
  images: [],
  captions: [],
  index: 0,

  open(images, captions = [], startIndex = 0) {
    if (!images || !images.length) return;
    this.images = images;
    this.captions = captions;
    this.index = Math.max(0, Math.min(startIndex, images.length - 1));

    let modal = document.getElementById('el-lightbox-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'el-lightbox-modal';
      modal.className = 'lightbox-modal';
      modal.setAttribute('role', 'dialog');
      modal.setAttribute('aria-modal', 'true');
      modal.innerHTML = `
        <div class="lightbox-modal__box">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.75rem;">
            <span id="lb-counter" style="font-size:0.85rem;color:#D8CFC0;">1 / 1</span>
            <button type="button" class="btn btn--outline btn--sm" id="lb-close" style="color:#FAF7F2;border-color:rgba(255,255,255,0.25);">Close ✕</button>
          </div>
          <div class="lightbox-modal__stage">
            <img id="lb-img" src="" alt="Property gallery photo" />
          </div>
          <div class="lightbox-modal__footer">
            <p id="lb-caption" style="margin:0;font-size:0.9rem;color:#E7DFCE;"></p>
            <div style="display:flex;gap:0.5rem;">
              <button type="button" class="btn btn--outline btn--sm" id="lb-prev" style="color:#FAF7F2;border-color:rgba(255,255,255,0.25);">← Prev</button>
              <button type="button" class="btn btn--primary btn--sm" id="lb-next">Next →</button>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(modal);

      modal.addEventListener('click', (e) => {
        if (e.target === modal) this.close();
      });
      modal.querySelector('#lb-close').addEventListener('click', () => this.close());
      modal.querySelector('#lb-prev').addEventListener('click', () => this.step(-1));
      modal.querySelector('#lb-next').addEventListener('click', () => this.step(1));
    }

    this.updateSlide(false);
    modal.classList.add('is-open');
  },

  step(delta) {
    this.index = (this.index + delta + this.images.length) % this.images.length;
    this.updateSlide(true);
  },

  updateSlide(animate) {
    const img = document.getElementById('lb-img');
    const cap = document.getElementById('lb-caption');
    const ctr = document.getElementById('lb-counter');
    if (!img) return;
    if (animate) {
      img.style.opacity = '0.25';
      img.style.transform = 'scale(0.985)';
      setTimeout(() => {
        img.src = this.images[this.index];
        img.style.opacity = '1';
        img.style.transform = 'scale(1)';
      }, 130);
    } else {
      img.src = this.images[this.index];
    }
    if (cap) cap.textContent = this.captions[this.index] || 'EasyLodging Luxury Suite';
    if (ctr) ctr.textContent = `${this.index + 1} / ${this.images.length}`;
  },

  close() {
    const modal = document.getElementById('el-lightbox-modal');
    if (modal) modal.classList.remove('is-open');
  }
};

function initScrollReveal() {
  const targets = document.querySelectorAll('.reveal-on-scroll');
  if (!targets.length) return;
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches || !('IntersectionObserver' in window)) {
    targets.forEach((el) => el.classList.add('is-visible'));
    return;
  }
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.1 }
  );
  targets.forEach((el) => observer.observe(el));
}

document.addEventListener('DOMContentLoaded', () => {
  ensureSeededState();
  initScrollReveal();
});
