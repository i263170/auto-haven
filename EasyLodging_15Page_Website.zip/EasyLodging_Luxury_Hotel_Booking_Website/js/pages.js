function initSavedStaysPage() {
  ensureSeededState();
  let activeChip = 'All Saved';
  const chipsWrap = document.getElementById('saved-collection-chips');
  const grid = document.getElementById('saved-stays-grid');

  const chips = ['All Saved', 'Collection 1', 'Collection 2'];
  if (chipsWrap) {
    chipsWrap.innerHTML = chips
      .map((c) => `<button type="button" class="filter-chip ${c === activeChip ? 'is-active' : ''}" data-saved-chip="${c}">${c}</button>`)
      .join('');

    chipsWrap.querySelectorAll('[data-saved-chip]').forEach((btn) => {
      btn.addEventListener('click', () => {
        activeChip = btn.dataset.savedChip;
        chipsWrap.querySelectorAll('[data-saved-chip]').forEach((b) => b.classList.toggle('is-active', b === btn));
        renderSaved();
      });
    });
  }

  document.getElementById('new-collection-btn')?.addEventListener('click', () => {
    showToast('Collection list ready—filter stays using All Saved or Collection chips.');
  });

  function renderSaved() {
    const savedIds = readStorage(EL_STORAGE_KEYS.SAVED_IDS, []);
    const hotels = getAllHotels(false);
    let savedHotels = hotels.filter((h) => savedIds.includes(h.id));

    if (activeChip === 'Collection 1') savedHotels = savedHotels.slice(0, 2);
    if (activeChip === 'Collection 2') savedHotels = savedHotels.slice(1);

    if (!grid) return;
    if (!savedHotels.length) {
      grid.innerHTML = `
        <div class="card" style="padding:2rem;grid-column:1/-1;text-align:center;">
          <h3 style="margin:0 0 0.45rem;font-family:var(--font-serif);">No saved stays yet</h3>
          <p class="section-subtitle" style="margin-bottom:1rem;">Browse properties and save your favorite luxury stays.</p>
          <a href="${routePath('search-results')}" class="btn btn--primary btn--sm">Explore Hotels</a>
        </div>
      `;
      return;
    }

    grid.innerHTML = savedHotels
      .map(
        (h) => `
      <article class="hotel-card">
        <div class="hotel-card__media">
          <img src="${h.resolvedImages[0]}" alt="${h.name}" />
        </div>
        <div class="hotel-card__body">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <span style="font-size:0.84rem;color:var(--ink-secondary);">${h.city} · ★ ${h.ratingScore}</span>
          </div>
          <h3 style="margin:0;font-family:var(--font-serif);font-size:1.15rem;">${h.name}</h3>
          <div class="price-tag">${formatPkr(h.pricePerNight)} <span>/ night</span></div>
          <div style="display:flex;gap:0.5rem;margin-top:auto;padding-top:0.5rem;">
            <a href="${routePath('property-details')}?id=${encodeURIComponent(h.id)}" class="btn btn--dark btn--sm" style="flex:1;">Book Now</a>
            <button type="button" class="btn btn--outline btn--sm" data-remove-saved="${h.id}">Remove</button>
          </div>
        </div>
      </article>
    `
      )
      .join('');

    grid.querySelectorAll('[data-remove-saved]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.removeSaved;
        const nextIds = readStorage(EL_STORAGE_KEYS.SAVED_IDS, []).filter((x) => x !== id);
        writeStorage(EL_STORAGE_KEYS.SAVED_IDS, nextIds);
        showToast('Removed stay from Saved Stays.');
        renderSaved();
      });
    });
  }

  renderSaved();
}

function initTravelerProfilePage() {
  ensureSeededState();
  const profile = readStorage(EL_STORAGE_KEYS.PROFILE, EL_SEED_DATA.defaultProfile);

  document.getElementById('prof-summary-name').textContent = profile.fullName;
  document.getElementById('prof-summary-email').textContent = profile.email;
  document.getElementById('prof-summary-since').textContent = `Member since ${profile.memberSince || 'March 2025'}`;

  const nameInput = document.getElementById('prof-fullname');
  const emailInput = document.getElementById('prof-email');
  const prefSelect = document.getElementById('prof-room-pref');
  const statusBadge = document.getElementById('prof-saved-badge');

  if (nameInput) nameInput.value = profile.fullName || '';
  if (emailInput) emailInput.value = profile.email || '';
  if (prefSelect && profile.roomPreference) prefSelect.value = profile.roomPreference;

  document.getElementById('traveler-profile-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const updated = {
      ...profile,
      signedIn: true,
      fullName: nameInput.value.trim() || 'Ayesha Siddiqui',
      email: emailInput.value.trim() || 'ayesha.siddiqui@example.pk',
      currency: 'PKR',
      roomPreference: prefSelect.value
    };
    writeStorage(EL_STORAGE_KEYS.PROFILE, updated);
    document.getElementById('prof-summary-name').textContent = updated.fullName;
    document.getElementById('prof-summary-email').textContent = updated.email;
    if (statusBadge) {
      statusBadge.style.display = 'inline-flex';
      statusBadge.textContent = '✓ Preferences saved · Rates now shown in PKR';
    }
    showToast('Preferences saved. Rates shown in PKR.');
  });
}

function initReviewsRatingsPage() {
  ensureSeededState();
  let selectedRating = 5;
  const starButtons = document.querySelectorAll('[data-pick-star]');
  const form = document.getElementById('review-submission-form');
  const errorEl = document.getElementById('review-form-error');
  const toastEl = document.getElementById('review-submitted-banner');

  function paintStars(val) {
    starButtons.forEach((b) => {
      const n = Number(b.dataset.pickStar);
      b.textContent = n <= val ? '★' : '☆';
      b.style.color = n <= val ? 'var(--gold-primary)' : 'var(--ink-muted)';
    });
  }

  starButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      selectedRating = Number(btn.dataset.pickStar);
      paintStars(selectedRating);
    });
  });
  paintStars(selectedRating);

  function renderReviewsList() {
    const reviews = readStorage(EL_STORAGE_KEYS.REVIEWS, EL_SEED_DATA.defaultReviews);
    const listWrap = document.getElementById('guest-reviews-list');
    const avgEl = document.getElementById('reviews-overall-score');
    const countEl = document.getElementById('reviews-total-count');

    const avg = reviews.length
      ? (reviews.reduce((s, r) => s + Number(r.rating || 5), 0) / reviews.length).toFixed(1)
      : '4.9';

    if (avgEl) avgEl.textContent = `★ ${avg}`;
    if (countEl) countEl.textContent = `${reviews.length} reviews out of 5`;

    if (listWrap) {
      listWrap.innerHTML = reviews
        .map(
          (r) => `
        <article class="card" style="padding:1.15rem 1.3rem;">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:0.5rem;margin-bottom:0.4rem;">
            <strong>${r.guestName}</strong>
            <span style="font-size:0.82rem;color:var(--ink-muted);">${r.monthYear}</span>
          </div>
          <div style="color:var(--gold-primary);font-size:0.95rem;margin-bottom:0.45rem;">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</div>
          <p style="margin:0;font-size:0.9rem;color:var(--ink-secondary);">${r.comment}</p>
        </article>
      `
        )
        .join('');
    }
  }

  form?.addEventListener('submit', (e) => {
    e.preventDefault();
    const nameInput = document.getElementById('review-guest-name');
    const textInput = document.getElementById('review-comment-text');
    const guestName = nameInput?.value.trim() || 'Guest Traveler';
    const comment = textInput?.value.trim() || '';

    if (!comment || comment.length < 6) {
      if (errorEl) errorEl.textContent = 'Please write a brief review before submitting.';
      textInput?.focus();
      return;
    }

    if (errorEl) errorEl.textContent = '';
    const list = readStorage(EL_STORAGE_KEYS.REVIEWS, EL_SEED_DATA.defaultReviews);
    list.unshift({
      id: `rev-${Date.now()}`,
      guestName,
      rating: selectedRating,
      monthYear: 'November 2026',
      comment
    });
    writeStorage(EL_STORAGE_KEYS.REVIEWS, list);
    if (textInput) textInput.value = '';
    if (toastEl) toastEl.style.display = 'block';
    showToast('Review submitted. Thanks for sharing your stay!');
    renderReviewsList();
  });

  renderReviewsList();
}

function initHostDashboardPage() {
  ensureSeededState();
  function renderHost() {
    const listings = readStorage(EL_STORAGE_KEYS.HOST_LISTINGS, EL_SEED_DATA.defaultHostListings);
    const activeCount = listings.filter((l) => l.status === 'Active').length;
    const nightsSum = listings.reduce((s, l) => s + Number(l.upcomingNights || 0), 0);
    const payoutSum = listings.reduce((s, l) => s + Number(l.nightlyPkr || 0) * Number(l.upcomingNights || 4), 0);
    const avgRating = listings.length
      ? (listings.reduce((s, l) => s + Number(l.rating || 4.8), 0) / listings.length).toFixed(1)
      : '4.9';

    document.getElementById('kpi-active-listings').textContent = String(activeCount);
    document.getElementById('kpi-upcoming-nights').textContent = `${nightsSum} nights`;
    document.getElementById('kpi-est-payout').textContent = formatPkr(payoutSum);
    document.getElementById('kpi-avg-rating').textContent = `★ ${avgRating}`;

    const tbody = document.getElementById('host-properties-tbody');
    const mobileCards = document.getElementById('host-properties-mobile');

    if (tbody) {
      tbody.innerHTML = listings
        .map(
          (item) => `
        <tr>
          <td>
            <div style="display:flex;align-items:center;gap:0.75rem;">
              <img src="${item.image}" alt="${item.name}" style="width:54px;height:40px;object-fit:cover;border-radius:6px;" />
              <strong>${item.name}</strong>
            </div>
          </td>
          <td>${item.city}</td>
          <td><strong>${formatPkr(item.nightlyPkr)}</strong></td>
          <td>
            <button type="button" class="badge ${item.status === 'Active' ? 'badge--success' : ''}" data-toggle-status="${item.id}">
              ${item.status}
            </button>
          </td>
          <td>
            <a href="${routePath('add-edit-listing')}?id=${encodeURIComponent(item.id)}" class="btn btn--dark btn--sm">Edit</a>
          </td>
        </tr>
      `
        )
        .join('');
    }

    if (mobileCards) {
      mobileCards.innerHTML = listings
        .map(
          (item) => `
        <div class="card" style="padding:1rem;margin-bottom:0.8rem;">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:0.5rem;">
            <div>
              <strong>${item.name}</strong>
              <div style="font-size:0.84rem;color:var(--ink-secondary);">${item.city} · ${formatPkr(item.nightlyPkr)} / night</div>
            </div>
            <button type="button" class="badge ${item.status === 'Active' ? 'badge--success' : ''}" data-toggle-status="${item.id}">${item.status}</button>
          </div>
          <div style="margin-top:0.75rem;">
            <a href="${routePath('add-edit-listing')}?id=${encodeURIComponent(item.id)}" class="btn btn--dark btn--sm">Edit</a>
          </div>
        </div>
      `
        )
        .join('');
    }

    document.querySelectorAll('[data-toggle-status]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.toggleStatus;
        const updated = listings.map((l) =>
          l.id === id ? { ...l, status: l.status === 'Active' ? 'Paused' : 'Active' } : l
        );
        writeStorage(EL_STORAGE_KEYS.HOST_LISTINGS, updated);
        showToast('Listing status updated.');
        renderHost();
      });
    });
  }

  renderHost();
}

function initAddEditListingPage() {
  ensureSeededState();
  const listings = readStorage(EL_STORAGE_KEYS.HOST_LISTINGS, EL_SEED_DATA.defaultHostListings);
  const params = new URLSearchParams(window.location.search);
  const editId = params.get('id');
  const existing = listings.find((l) => l.id === editId);

  const nameInput = document.getElementById('lst-name');
  const cityInput = document.getElementById('lst-city');
  const catSelect = document.getElementById('lst-category');
  const rateInput = document.getElementById('lst-rate');
  const amenityBoxes = Array.from(document.querySelectorAll('[data-lst-amenity]'));

  if (existing) {
    if (nameInput) nameInput.value = existing.name;
    if (cityInput) cityInput.value = existing.city;
    if (catSelect) catSelect.value = existing.category || 'Luxury Hotel';
    if (rateInput) rateInput.value = existing.nightlyPkr;
    amenityBoxes.forEach((cb) => {
      cb.checked = (existing.amenities || []).includes(cb.value);
    });
  }

  function refreshPreview() {
    const pName = nameInput?.value.trim() || 'Property name';
    const pCity = cityInput?.value.trim() || 'City / address';
    const pCat = catSelect?.value || 'Category';
    const pRate = Number(rateInput?.value || 0);

    document.getElementById('prev-lst-name').textContent = pName;
    document.getElementById('prev-lst-city').textContent = `${pCity} · ${pCat}`;
    document.getElementById('prev-lst-rate').textContent = `${formatPkr(pRate)} / night`;
  }

  [nameInput, cityInput, catSelect, rateInput].forEach((el) => el?.addEventListener('input', refreshPreview));
  refreshPreview();

  const form = document.getElementById('add-edit-listing-form');
  const errEl = document.getElementById('lst-form-error');
  const toastEl = document.getElementById('lst-saved-toast');

  form?.addEventListener('submit', (e) => {
    e.preventDefault();
    const nameVal = nameInput.value.trim();
    const cityVal = cityInput.value.trim();
    const rateVal = Number(rateInput.value);

    if (!nameVal || !cityVal || !rateVal || rateVal < 1000) {
      if (errEl) errEl.textContent = 'Please enter property name, city/address, and a valid nightly PKR rate.';
      return;
    }

    if (errEl) errEl.textContent = '';
    const chosenAmenities = amenityBoxes.filter((c) => c.checked).map((c) => c.value);
    const currentList = readStorage(EL_STORAGE_KEYS.HOST_LISTINGS, EL_SEED_DATA.defaultHostListings);

    if (existing) {
      const idx = currentList.findIndex((item) => item.id === existing.id);
      if (idx >= 0) {
        currentList[idx] = {
          ...currentList[idx],
          name: nameVal,
          city: cityVal,
          category: catSelect.value,
          nightlyPkr: rateVal,
          amenities: chosenAmenities
        };
      }
    } else {
      currentList.unshift({
        id: `host-${Date.now()}`,
        name: nameVal,
        city: cityVal,
        category: catSelect.value,
        nightlyPkr: rateVal,
        status: 'Active',
        upcomingNights: 5,
        rating: 4.9,
        amenities: chosenAmenities,
        image: '../images/frames-for-your-heart-zSG-kd-L6vw-unsplash.jpg'
      });
    }

    writeStorage(EL_STORAGE_KEYS.HOST_LISTINGS, currentList);
    if (toastEl) toastEl.style.display = 'inline-flex';
    showToast('Listing saved to EasyLodging.');
  });
}

function initHelpCenterPage() {
  const faqs = [
    {
      q: 'How are room and add-on totals calculated in PKR?',
      a: 'Room totals multiply the selected room category nightly rate in PKR by your stay nights, plus any selected add-ons such as Airport Pickup or Extra Bed.'
    },
    {
      q: 'What identification is required at property check-in?',
      a: 'Guests should carry a valid CNIC or passport matching the primary reservation name along with their EasyLodging booking reference.'
    },
    {
      q: 'Can I modify dates or cancel a reservation?',
      a: 'Yes. Open My Bookings and choose Manage Trip on any upcoming reservation to adjust dates/guests or cancel with confirmation.'
    },
    {
      q: 'Is payment processed live on this site?',
      a: 'No real payment gateway is connected. Pay at Property and Card / Transfer selections are simulated locally for academic demonstration.'
    }
  ];

  const accWrap = document.getElementById('help-faq-accordion');
  const searchInput = document.getElementById('help-search-input');

  function renderFaqs(filterText = '') {
    if (!accWrap) return;
    const q = filterText.trim().toLowerCase();
    const items = faqs.filter((f) => !q || f.q.toLowerCase().includes(q) || f.a.toLowerCase().includes(q));
    accWrap.innerHTML = items
      .map(
        (f, i) => `
      <div class="accordion-item ${i === 0 ? 'is-open' : ''}">
        <button type="button" class="accordion-trigger" aria-expanded="${i === 0}">
          <span>${f.q}</span>
          <span>+</span>
        </button>
        <div class="accordion-panel">${f.a}</div>
      </div>
    `
      )
      .join('');

    accWrap.querySelectorAll('.accordion-trigger').forEach((btn) => {
      btn.addEventListener('click', () => {
        const parent = btn.closest('.accordion-item');
        const isOpen = parent.classList.contains('is-open');
        accWrap.querySelectorAll('.accordion-item').forEach((item) => item.classList.remove('is-open'));
        if (!isOpen) parent.classList.add('is-open');
      });
    });
  }

  searchInput?.addEventListener('input', (e) => renderFaqs(e.target.value));
  document.getElementById('contact-support-btn')?.addEventListener('click', () => {
    showToast('Concierge Support ticket opened (concierge@easylodging.pk).');
  });

  renderFaqs();
}
