function initPropertyDetailsPage() {
  ensureSeededState();
  const hotels = getAllHotels(false);
  const params = new URLSearchParams(window.location.search);
  const requestedId = params.get('id');
  const draft = readStorage(EL_STORAGE_KEYS.BOOKING_DRAFT, null);
  const searchState = readStorage(EL_STORAGE_KEYS.SEARCH, EL_SEED_DATA.defaultSearch);

  let currentHotel =
    hotels.find((h) => h.id === requestedId) ||
    hotels.find((h) => h.id === draft?.hotelId) ||
    hotels[0];

  const switcher = document.getElementById('property-switcher');
  if (switcher) {
    switcher.innerHTML = hotels
      .map((h) => `<option value="${h.id}" ${h.id === currentHotel.id ? 'selected' : ''}>${h.name} (${h.city})</option>`)
      .join('');
    switcher.addEventListener('change', (e) => {
      currentHotel = hotels.find((h) => h.id === e.target.value) || hotels[0];
      renderHotelDetails();
    });
  }

  let checkInVal = draft?.checkIn || searchState.checkIn || '2026-12-12';
  let checkOutVal = draft?.checkOut || searchState.checkOut || '2026-12-15';
  let guestsVal = draft?.guests || (searchState.adults || 2) + (searchState.children || 0);

  function renderHotelDetails() {
    const titleEl = document.getElementById('prop-title');
    const metaEl = document.getElementById('prop-meta');
    const descEl = document.getElementById('prop-description');
    const mainImg = document.getElementById('prop-main-img');
    const thumbsWrap = document.getElementById('prop-thumbs');
    const amenGrid = document.getElementById('prop-amenities-grid');
    const nightlyEl = document.getElementById('prop-nightly-price');
    const mobileNightlyEl = document.getElementById('mobile-bar-price');
    const cancelBadge = document.getElementById('prop-cancel-status');

    if (titleEl) titleEl.textContent = currentHotel.name;
    if (metaEl) metaEl.textContent = `${currentHotel.area}, ${currentHotel.city} · ★ ${currentHotel.ratingScore} (${currentHotel.reviewCount} reviews)`;
    if (descEl) descEl.textContent = currentHotel.description;
    if (nightlyEl) nightlyEl.textContent = formatPkr(currentHotel.pricePerNight);
    if (mobileNightlyEl) mobileNightlyEl.textContent = formatPkr(currentHotel.pricePerNight);
    if (cancelBadge) {
      cancelBadge.textContent = currentHotel.freeCancellation ? '✓ Free cancellation up to 48h prior' : 'Standard booking terms apply';
      cancelBadge.className = `badge ${currentHotel.freeCancellation ? 'badge--success' : ''}`;
    }

    const galleryImgs = currentHotel.images;
    const captions = [
      `${currentHotel.name} — Signature Lounge & Architecture`,
      `${currentHotel.name} — Suite Interior & Finishes`,
      `${currentHotel.name} — Courtyard & Leisure View`,
      `${currentHotel.name} — Guest Retreat Detail`
    ];

    if (mainImg) {
      mainImg.src = galleryImgs[0];
      mainImg.alt = captions[0];
      document.getElementById('prop-main-trigger')?.addEventListener('click', () => {
        Lightbox.open(galleryImgs, captions, 0);
      });
    }

    if (thumbsWrap) {
      thumbsWrap.innerHTML = galleryImgs
        .slice(1, 4)
        .map(
          (src, i) => `
        <button type="button" class="gallery-thumb" aria-label="Open photo ${i + 2}" data-lb-idx="${i + 1}">
          <img src="${src}" alt="${captions[i + 1]}" />
        </button>
      `
        )
        .join('');
      thumbsWrap.querySelectorAll('[data-lb-idx]').forEach((btn) => {
        btn.addEventListener('click', () => Lightbox.open(galleryImgs, captions, Number(btn.dataset.lbIdx)));
      });
    }

    const iconMap = {
      'Wi-Fi': '📶',
      Parking: '🅿️',
      Pool: '🏊',
      Breakfast: '☕',
      AC: '❄️',
      Laundry: '👔'
    };
    const allAmenities = ['Wi-Fi', 'Parking', 'Pool', 'Breakfast', 'AC', 'Laundry'];
    if (amenGrid) {
      amenGrid.innerHTML = allAmenities
        .map((am) => {
          const available = currentHotel.amenities.includes(am);
          return `<div class="amenity-tile" style="${available ? '' : 'opacity:0.48;'}">
            <span>${iconMap[am] || '✦'}</span>
            <span>${am}</span>
          </div>`;
        })
        .join('');
    }

    updateBookingEstimate();
  }

  const inInput = document.getElementById('prop-checkin');
  const outInput = document.getElementById('prop-checkout');
  const guestsSelect = document.getElementById('prop-guests');
  if (inInput) inInput.value = checkInVal;
  if (outInput) outInput.value = checkOutVal;
  if (guestsSelect) guestsSelect.value = String(guestsVal);

  function updateBookingEstimate() {
    checkInVal = inInput?.value || checkInVal;
    checkOutVal = outInput?.value || checkOutVal;
    guestsVal = Number(guestsSelect?.value || guestsVal);
    const nights = calculateNights(checkInVal, checkOutVal);
    const total = currentHotel.pricePerNight * nights;

    const nightsEl = document.getElementById('prop-nights-calc');
    const totalEl = document.getElementById('prop-total-calc');
    if (nightsEl) nightsEl.textContent = `${formatPkr(currentHotel.pricePerNight)} × ${nights} ${nights === 1 ? 'night' : 'nights'}`;
    if (totalEl) totalEl.textContent = formatPkr(total);
  }

  inInput?.addEventListener('change', updateBookingEstimate);
  outInput?.addEventListener('change', updateBookingEstimate);
  guestsSelect?.addEventListener('change', updateBookingEstimate);

  function goToRooms() {
    updateBookingEstimate();
    const nights = calculateNights(checkInVal, checkOutVal);
    const defaultRoom = currentHotel.rooms[0];
    const roomRate = Math.round(currentHotel.pricePerNight * defaultRoom.rateMultiplier);

    const draftPayload = {
      hotelId: currentHotel.id,
      hotelName: currentHotel.name,
      city: currentHotel.city,
      baseNightlyPkr: currentHotel.pricePerNight,
      checkIn: checkInVal,
      checkOut: checkOutVal,
      nights,
      guests: guestsVal,
      roomId: defaultRoom.id,
      roomName: defaultRoom.name,
      roomPricePerNight: roomRate,
      addonIds: draft?.addonIds || [],
      totalPkr: roomRate * nights
    };
    writeStorage(EL_STORAGE_KEYS.BOOKING_DRAFT, draftPayload);
    window.location.href = routePath('rooms-addons');
  }

  document.getElementById('check-rooms-btn')?.addEventListener('click', goToRooms);
  document.getElementById('mobile-check-rooms-btn')?.addEventListener('click', goToRooms);

  renderHotelDetails();
}

function initRoomsAddonsPage() {
  ensureSeededState();
  const hotels = getAllHotels(false);
  let draft = readStorage(EL_STORAGE_KEYS.BOOKING_DRAFT, null);
  const searchState = readStorage(EL_STORAGE_KEYS.SEARCH, EL_SEED_DATA.defaultSearch);

  if (!draft) {
    const fallbackHotel = hotels[0];
    const nights = calculateNights(searchState.checkIn, searchState.checkOut);
    draft = {
      hotelId: fallbackHotel.id,
      hotelName: fallbackHotel.name,
      city: fallbackHotel.city,
      baseNightlyPkr: fallbackHotel.pricePerNight,
      checkIn: searchState.checkIn || '2026-12-12',
      checkOut: searchState.checkOut || '2026-12-15',
      nights,
      guests: (searchState.adults || 2) + (searchState.children || 0),
      roomId: fallbackHotel.rooms[0].id,
      roomName: fallbackHotel.rooms[0].name,
      roomPricePerNight: fallbackHotel.pricePerNight,
      addonIds: [],
      totalPkr: fallbackHotel.pricePerNight * nights
    };
  }

  const hotel = hotels.find((h) => h.id === draft.hotelId) || hotels[0];
  let selectedRoom = hotel.rooms.find((r) => r.id === draft.roomId) || hotel.rooms[0];
  let selectedAddonIds = new Set(draft.addonIds || []);

  const roomsWrap = document.getElementById('room-categories-grid');
  if (roomsWrap) {
    roomsWrap.innerHTML = hotel.rooms
      .map((room) => {
        const nightly = Math.round(hotel.pricePerNight * room.rateMultiplier);
        const isSelected = room.id === selectedRoom.id;
        return `
        <article class="card" style="padding:1.25rem;border-color:${isSelected ? 'var(--gold-primary)' : 'var(--border-subtle)'};">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:0.75rem;flex-wrap:wrap;">
            <div>
              <h3 style="margin:0;font-family:var(--font-serif);font-size:1.18rem;">${room.name}</h3>
              <p style="margin:0.25rem 0 0;font-size:0.86rem;color:var(--ink-secondary);">Sleeps ${room.capacity} · ${room.bedType}</p>
            </div>
            <div class="price-tag">${formatPkr(nightly)} <span>/ night</span></div>
          </div>
          <div style="margin-top:1rem;">
            <button type="button" class="btn ${isSelected ? 'btn--dark' : 'btn--primary'} btn--sm" data-select-room="${room.id}">
              ${isSelected ? '✓ Selected Room' : 'Select Room'}
            </button>
          </div>
        </article>
      `;
      })
      .join('');

    roomsWrap.querySelectorAll('[data-select-room]').forEach((btn) => {
      btn.addEventListener('click', () => {
        selectedRoom = hotel.rooms.find((r) => r.id === btn.dataset.selectRoom) || hotel.rooms[0];
        initRoomsAddonsPage();
      });
    });
  }

  const addonsWrap = document.getElementById('addons-list');
  if (addonsWrap) {
    addonsWrap.innerHTML = EL_SEED_DATA.addons
      .map((ad) => {
        const checked = selectedAddonIds.has(ad.id);
        return `
        <label style="display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:0.85rem 1rem;border:1px solid var(--border-subtle);border-radius:var(--radius-sm);background:var(--bg-ivory);cursor:pointer;">
          <span style="display:flex;align-items:center;gap:0.7rem;">
            <input type="checkbox" data-addon-id="${ad.id}" ${checked ? 'checked' : ''} />
            <span>
              <strong style="display:block;font-size:0.92rem;">${ad.label}</strong>
              <span style="font-size:0.8rem;color:var(--ink-secondary);">${ad.description}</span>
            </span>
          </span>
          <strong style="color:var(--gold-hover);white-space:nowrap;">+ ${formatPkr(ad.pricePkr)}</strong>
        </label>
      `;
      })
      .join('');

    addonsWrap.querySelectorAll('[data-addon-id]').forEach((cb) => {
      cb.addEventListener('change', () => {
        if (cb.checked) selectedAddonIds.add(cb.dataset.addonId);
        else selectedAddonIds.delete(cb.dataset.addonId);
        recalculateStay();
      });
    });
  }

  function recalculateStay() {
    const nights = calculateNights(draft.checkIn, draft.checkOut);
    const roomNightly = Math.round(hotel.pricePerNight * selectedRoom.rateMultiplier);
    const roomSubtotal = roomNightly * nights;
    const chosenAddons = EL_SEED_DATA.addons.filter((a) => selectedAddonIds.has(a.id));
    const addonsTotal = chosenAddons.reduce((sum, a) => sum + a.pricePkr, 0);
    const grandTotal = roomSubtotal + addonsTotal;

    const roomLabel = document.getElementById('stay-summary-room');
    const addonsLabel = document.getElementById('stay-summary-addons');
    const nightsLabel = document.getElementById('stay-summary-nights');
    const totalEl = document.getElementById('stay-live-total');
    const mobileTotalEl = document.getElementById('mobile-live-total');

    if (roomLabel) roomLabel.textContent = `${selectedRoom.name} (${formatPkr(roomNightly)}/night)`;
    if (addonsLabel) addonsLabel.textContent = chosenAddons.length ? chosenAddons.map((a) => a.label).join(', ') : 'None selected';
    if (nightsLabel) nightsLabel.textContent = `${nights} ${nights === 1 ? 'night' : 'nights'} · ${draft.guests} guests`;
    if (totalEl) totalEl.textContent = formatPkr(grandTotal);
    if (mobileTotalEl) mobileTotalEl.textContent = formatPkr(grandTotal);

    draft = {
      ...draft,
      hotelId: hotel.id,
      hotelName: hotel.name,
      city: hotel.city,
      nights,
      roomId: selectedRoom.id,
      roomName: selectedRoom.name,
      roomPricePerNight: roomNightly,
      addonIds: Array.from(selectedAddonIds),
      addons: chosenAddons,
      totalPkr: grandTotal
    };
    writeStorage(EL_STORAGE_KEYS.BOOKING_DRAFT, draft);
  }

  function proceedToCheckout() {
    recalculateStay();
    window.location.href = routePath('checkout');
  }

  document.getElementById('continue-to-checkout-btn')?.addEventListener('click', proceedToCheckout);
  document.getElementById('mobile-continue-checkout-btn')?.addEventListener('click', proceedToCheckout);

  recalculateStay();
}

function initCheckoutPage() {
  ensureSeededState();
  const profile = readStorage(EL_STORAGE_KEYS.PROFILE, EL_SEED_DATA.defaultProfile);
  const draft = readStorage(EL_STORAGE_KEYS.BOOKING_DRAFT, null) || {
    hotelId: 'margalla-crest-palace',
    hotelName: 'The Margalla Crest Palace',
    city: 'Islamabad',
    roomName: 'Deluxe Courtyard King',
    roomPricePerNight: 36000,
    checkIn: '2026-12-12',
    checkOut: '2026-12-15',
    nights: 3,
    guests: 2,
    addons: [],
    totalPkr: 108000
  };

  const nameInput = document.getElementById('checkout-fullname');
  const emailInput = document.getElementById('checkout-email');
  const phoneInput = document.getElementById('checkout-phone');
  if (nameInput && !nameInput.value) nameInput.value = profile.fullName || '';
  if (emailInput && !emailInput.value) emailInput.value = profile.email || '';
  if (phoneInput && !phoneInput.value) phoneInput.value = profile.phone || '';

  const addonsList = draft.addons || EL_SEED_DATA.addons.filter((a) => (draft.addonIds || []).includes(a.id));
  const addonsCost = addonsList.reduce((acc, item) => acc + item.pricePkr, 0);
  const computedTotal = (draft.roomPricePerNight || 36000) * (draft.nights || 1) + addonsCost;

  document.getElementById('co-hotel-name').textContent = draft.hotelName;
  document.getElementById('co-room-name').textContent = `${draft.roomName} · ${draft.checkIn} to ${draft.checkOut}`;
  document.getElementById('co-nights-guests').textContent = `${draft.nights} ${draft.nights === 1 ? 'night' : 'nights'} · ${draft.guests} guests`;
  document.getElementById('co-addons-text').textContent = addonsList.length
    ? `${addonsList.map((a) => a.label).join(', ')} (${formatPkr(addonsCost)})`
    : 'No add-ons';
  document.getElementById('co-total-pkr').textContent = formatPkr(computedTotal);

  const form = document.getElementById('checkout-payment-form');
  const errorBox = document.getElementById('checkout-error-msg');
  const toastBox = document.getElementById('checkout-inline-confirmation');

  form?.addEventListener('submit', (e) => {
    e.preventDefault();
    const fullName = nameInput.value.trim();
    const email = emailInput.value.trim();
    const phone = phoneInput.value.trim();
    const paymentRadio = form.querySelector('input[name="paymentMethod"]:checked');
    const policyAccepted = document.getElementById('accept-policy-cb')?.checked;

    if (!fullName || fullName.length < 2) {
      errorBox.textContent = 'Please enter your full name.';
      nameInput.focus();
      return;
    }
    if (!email || !email.includes('@')) {
      errorBox.textContent = 'Please enter a valid email address.';
      emailInput.focus();
      return;
    }
    if (!phone || phone.length < 7) {
      errorBox.textContent = 'Please enter a valid contact phone number.';
      phoneInput.focus();
      return;
    }
    if (!policyAccepted) {
      errorBox.textContent = 'Please accept the cancellation policy to confirm your reservation.';
      return;
    }

    errorBox.textContent = '';
    const refCode = `EL-${Math.floor(10000 + Math.random() * 90000)}`;
    const newBooking = {
      ref: refCode,
      hotelId: draft.hotelId,
      hotelName: draft.hotelName,
      city: draft.city,
      roomName: draft.roomName,
      roomPricePerNight: draft.roomPricePerNight,
      checkIn: draft.checkIn,
      checkOut: draft.checkOut,
      nights: draft.nights,
      guests: draft.guests,
      addons: addonsList,
      totalPkr: computedTotal,
      paymentMethod: paymentRadio ? paymentRadio.value : 'Pay at Property',
      guestName: fullName,
      guestEmail: email,
      guestPhone: phone,
      status: 'Upcoming'
    };

    const existingBookings = readStorage(EL_STORAGE_KEYS.BOOKINGS, EL_SEED_DATA.defaultBookings);
    existingBookings.unshift(newBooking);
    writeStorage(EL_STORAGE_KEYS.BOOKINGS, existingBookings);
    writeStorage(EL_STORAGE_KEYS.BOOKING_DRAFT, { ...draft, latestRef: refCode, totalPkr: computedTotal });

    showToast(`Reservation ${refCode} confirmed for ${draft.hotelName}!`);
    if (toastBox) {
      toastBox.style.display = 'block';
      toastBox.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:space-between;gap:1rem;flex-wrap:wrap;">
          <div>
            <strong>✓ Reservation confirmed (${refCode})</strong>
            <div style="font-size:0.84rem;color:var(--ink-secondary);">Confirmation details prepared for ${email}.</div>
          </div>
          <a href="${routePath('booking-confirmation')}?ref=${encodeURIComponent(refCode)}" class="btn btn--primary btn--sm">View Confirmation →</a>
        </div>
      `;
    }

    setTimeout(() => {
      window.location.href = `${routePath('booking-confirmation')}?ref=${encodeURIComponent(refCode)}`;
    }, 650);
  });
}

function initConfirmationPage() {
  ensureSeededState();
  const bookings = readStorage(EL_STORAGE_KEYS.BOOKINGS, EL_SEED_DATA.defaultBookings);
  const params = new URLSearchParams(window.location.search);
  const refParam = params.get('ref');
  const booking = bookings.find((b) => b.ref === refParam) || bookings[0];

  if (!booking) return;
  const hotels = getAllHotels(false);
  const hotel = hotels.find((h) => h.id === booking.hotelId) || hotels[0];

  document.getElementById('conf-ref-code').textContent = booking.ref;
  document.getElementById('conf-hotel-name').textContent = booking.hotelName;
  document.getElementById('conf-city-rating').textContent = `${booking.city} · ★ ${hotel.ratingScore}`;
  document.getElementById('conf-hotel-img').src = hotel.resolvedImages[0];
  document.getElementById('conf-checkin').textContent = booking.checkIn;
  document.getElementById('conf-checkout').textContent = booking.checkOut;
  document.getElementById('conf-room-nights').textContent = `${booking.roomName} · ${booking.nights} ${booking.nights === 1 ? 'night' : 'nights'}`;
  document.getElementById('conf-guests').textContent = `${booking.guests} guests`;
  document.getElementById('conf-total').textContent = formatPkr(booking.totalPkr);
  document.getElementById('conf-email-note').textContent = `Confirmation sent to ${booking.guestEmail || 'your email'}`;

  document.getElementById('conf-modify-link').href = `${routePath('modify-cancel')}?ref=${encodeURIComponent(booking.ref)}`;
  document.getElementById('conf-print-btn')?.addEventListener('click', () => window.print());
}

function initMyBookingsPage() {
  ensureSeededState();
  let activeTab = 'Upcoming';
  const tabsWrap = document.getElementById('booking-status-tabs');
  const listWrap = document.getElementById('my-bookings-list');

  tabsWrap?.querySelectorAll('[data-booking-tab]').forEach((btn) => {
    btn.addEventListener('click', () => {
      activeTab = btn.dataset.bookingTab;
      tabsWrap.querySelectorAll('[data-booking-tab]').forEach((b) => b.classList.toggle('is-active', b === btn));
      renderBookings();
    });
  });

  function renderBookings() {
    const allBookings = readStorage(EL_STORAGE_KEYS.BOOKINGS, EL_SEED_DATA.defaultBookings);
    const hotels = getAllHotels(false);
    const filtered = allBookings.filter((b) => b.status === activeTab);

    if (!listWrap) return;
    if (!filtered.length) {
      listWrap.innerHTML = `
        <div class="card" style="padding:2.25rem;text-align:center;">
          <h3 style="margin:0 0 0.45rem;font-family:var(--font-serif);">No ${activeTab.toLowerCase()} bookings</h3>
          <p class="section-subtitle" style="margin-bottom:1.1rem;">Explore luxury suites across Pakistan and reserve with transparent PKR pricing.</p>
          <a href="${routePath('search-results')}" class="btn btn--primary btn--sm">Find Stays</a>
        </div>
      `;
      return;
    }

    listWrap.innerHTML = filtered
      .map((b) => {
        const hotel = hotels.find((h) => h.id === b.hotelId) || hotels[0];
        const badgeClass = b.status === 'Upcoming' ? 'badge--success' : b.status === 'Cancelled' ? '' : 'badge--gold';
        return `
        <article class="result-card">
          <div style="overflow:hidden;">
            <img src="${hotel.resolvedImages[0]}" alt="${b.hotelName}" class="result-card__img" />
          </div>
          <div style="padding:1.15rem 1.3rem;display:flex;flex-direction:column;justify-content:space-between;gap:0.75rem;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:0.75rem;flex-wrap:wrap;">
              <div>
                <div style="font-size:0.78rem;font-weight:700;color:var(--ink-muted);">REF: ${b.ref}</div>
                <h3 style="margin:0.15rem 0;font-family:var(--font-serif);font-size:1.2rem;">${b.hotelName}</h3>
                <div style="font-size:0.86rem;color:var(--ink-secondary);">${b.roomName} · ${b.checkIn} to ${b.checkOut}</div>
              </div>
              <span class="badge ${badgeClass}">${b.status}</span>
            </div>

            <div style="display:flex;align-items:center;justify-content:space-between;gap:1rem;padding-top:0.65rem;border-top:1px solid var(--border-subtle);flex-wrap:wrap;">
              <div class="price-tag">${formatPkr(b.totalPkr)}</div>
              <a href="${routePath('modify-cancel')}?ref=${encodeURIComponent(b.ref)}" class="btn btn--dark btn--sm">Manage Trip</a>
            </div>
          </div>
        </article>
      `;
      })
      .join('');
  }

  renderBookings();
}

function initModifyCancelPage() {
  ensureSeededState();
  const bookings = readStorage(EL_STORAGE_KEYS.BOOKINGS, EL_SEED_DATA.defaultBookings);
  const params = new URLSearchParams(window.location.search);
  const refParam = params.get('ref');
  let booking = bookings.find((b) => b.ref === refParam) || bookings[0];

  if (!booking) return;

  let editCheckIn = booking.checkIn;
  let editCheckOut = booking.checkOut;
  let editGuests = booking.guests || 2;

  const inInput = document.getElementById('mod-checkin');
  const outInput = document.getElementById('mod-checkout');
  const guestsEl = document.getElementById('mod-guests-val');
  const feedbackEl = document.getElementById('mod-feedback-msg');
  const confirmBox = document.getElementById('cancel-confirm-dialog');

  document.getElementById('mod-ref-badge').textContent = booking.ref;
  document.getElementById('mod-cur-hotel').textContent = booking.hotelName;
  document.getElementById('mod-cur-room').textContent = booking.roomName;
  document.getElementById('mod-cur-dates').textContent = `${booking.checkIn} → ${booking.checkOut}`;
  document.getElementById('mod-cur-total').textContent = formatPkr(booking.totalPkr);

  if (inInput) inInput.value = editCheckIn;
  if (outInput) outInput.value = editCheckOut;
  if (guestsEl) guestsEl.textContent = editGuests;

  function computeNewTotal() {
    const nights = calculateNights(inInput?.value || editCheckIn, outInput?.value || editCheckOut);
    const addonsSum = (booking.addons || []).reduce((acc, a) => acc + (a.pricePkr || 0), 0);
    const total = (booking.roomPricePerNight || 36000) * nights + addonsSum;
    const liveTotalEl = document.getElementById('mod-live-total');
    if (liveTotalEl) liveTotalEl.textContent = formatPkr(total);
    return { nights, total };
  }

  inInput?.addEventListener('change', computeNewTotal);
  outInput?.addEventListener('change', computeNewTotal);

  document.getElementById('mod-guest-minus')?.addEventListener('click', () => {
    editGuests = Math.max(1, editGuests - 1);
    if (guestsEl) guestsEl.textContent = editGuests;
  });

  document.getElementById('mod-guest-plus')?.addEventListener('click', () => {
    editGuests = Math.min(8, editGuests + 1);
    if (guestsEl) guestsEl.textContent = editGuests;
  });

  document.getElementById('save-date-changes-btn')?.addEventListener('click', () => {
    const newIn = inInput.value;
    const newOut = outInput.value;
    if (!newIn || !newOut || new Date(newOut) <= new Date(newIn)) {
      if (feedbackEl) {
        feedbackEl.className = 'form-error';
        feedbackEl.textContent = 'Check-out date must be after check-in date.';
      }
      return;
    }

    const { nights, total } = computeNewTotal();
    const list = readStorage(EL_STORAGE_KEYS.BOOKINGS, EL_SEED_DATA.defaultBookings);
    const idx = list.findIndex((item) => item.ref === booking.ref);
    if (idx >= 0) {
      list[idx] = {
        ...list[idx],
        checkIn: newIn,
        checkOut: newOut,
        nights,
        guests: editGuests,
        totalPkr: total,
        status: 'Upcoming'
      };
      booking = list[idx];
      writeStorage(EL_STORAGE_KEYS.BOOKINGS, list);
    }

    document.getElementById('mod-cur-dates').textContent = `${newIn} → ${newOut}`;
    document.getElementById('mod-cur-total').textContent = formatPkr(total);
    if (feedbackEl) {
      feedbackEl.className = 'badge badge--success';
      feedbackEl.textContent = '✓ Booking dates and guest count updated.';
    }
    showToast('Booking changes saved.');
  });

  document.getElementById('open-cancel-dialog-btn')?.addEventListener('click', () => {
    if (confirmBox) confirmBox.style.display = 'block';
  });

  document.getElementById('keep-booking-btn')?.addEventListener('click', () => {
    if (confirmBox) confirmBox.style.display = 'none';
  });

  document.getElementById('confirm-cancel-booking-btn')?.addEventListener('click', () => {
    const list = readStorage(EL_STORAGE_KEYS.BOOKINGS, EL_SEED_DATA.defaultBookings);
    const idx = list.findIndex((item) => item.ref === booking.ref);
    if (idx >= 0) {
      list[idx].status = 'Cancelled';
      writeStorage(EL_STORAGE_KEYS.BOOKINGS, list);
    }
    if (confirmBox) confirmBox.style.display = 'none';
    if (feedbackEl) {
      feedbackEl.className = 'badge';
      feedbackEl.textContent = `Booking ${booking.ref} has been cancelled.`;
    }
    showToast(`Booking ${booking.ref} cancelled.`);
  });

  computeNewTotal();
}
