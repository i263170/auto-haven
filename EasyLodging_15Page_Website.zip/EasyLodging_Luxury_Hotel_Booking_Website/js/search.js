function initHomePage() {
  ensureSeededState();
  const searchState = readStorage(EL_STORAGE_KEYS.SEARCH, EL_SEED_DATA.defaultSearch);
  const destInput = document.getElementById('search-destination');
  const checkInInput = document.getElementById('search-checkin');
  const checkOutInput = document.getElementById('search-checkout');
  const guestsSummaryBtn = document.getElementById('guests-summary-btn');
  const guestsSummaryText = document.getElementById('guests-summary-text');
  const dropdown = document.getElementById('search-flow-dropdown');
  const errorBox = document.getElementById('search-validation-error');
  const form = document.getElementById('hero-search-form');

  if (destInput) destInput.value = searchState.destination || '';
  if (checkInInput) checkInInput.value = searchState.checkIn || '2026-12-12';
  if (checkOutInput) checkOutInput.value = searchState.checkOut || '2026-12-15';

  let counts = {
    adults: searchState.adults || 2,
    children: searchState.children || 0,
    rooms: searchState.rooms || 1
  };

  function syncGuestText() {
    const totalGuests = counts.adults + counts.children;
    if (guestsSummaryText) {
      guestsSummaryText.textContent = `${totalGuests} Guests · ${counts.rooms} ${counts.rooms === 1 ? 'Room' : 'Rooms'}`;
    }
    ['adults', 'children', 'rooms'].forEach((k) => {
      const el = document.getElementById(`count-${k}`);
      if (el) el.textContent = counts[k];
    });
  }

  function openDropdown(mode = 'destination') {
    if (!dropdown) return;
    dropdown.classList.add('is-open');
    document.getElementById('panel-destination').style.display = mode === 'destination' ? 'block' : 'none';
    document.getElementById('panel-dates').style.display = mode === 'dates' ? 'block' : 'none';
    document.getElementById('panel-guests').style.display = mode === 'guests' ? 'block' : 'none';
  }

  function renderDestinationChips() {
    const recentWrap = document.getElementById('recent-destinations-chips');
    const suggWrap = document.getElementById('suggested-destinations-chips');
    const state = readStorage(EL_STORAGE_KEYS.SEARCH, EL_SEED_DATA.defaultSearch);
    const recents = state.recentDestinations || ['Islamabad', 'Hunza Valley'];
    const suggested = ['Islamabad', 'Hunza Valley', 'Skardu', 'Lahore'];

    if (recentWrap) {
      recentWrap.innerHTML = recents
        .map((c) => `<button type="button" class="filter-chip" data-pick-city="${c}">${c}</button>`)
        .join('');
    }
    if (suggWrap) {
      suggWrap.innerHTML = suggested
        .map((c) => `<button type="button" class="filter-chip" data-pick-city="${c}">${c}</button>`)
        .join('');
    }

    dropdown?.querySelectorAll('[data-pick-city]').forEach((btn) => {
      btn.addEventListener('click', () => {
        if (destInput) destInput.value = btn.dataset.pickCity;
        if (errorBox) errorBox.textContent = '';
        openDropdown('dates');
      });
    });
  }

  destInput?.addEventListener('focus', () => openDropdown('destination'));
  checkInInput?.addEventListener('focus', () => openDropdown('dates'));
  checkOutInput?.addEventListener('focus', () => openDropdown('dates'));
  guestsSummaryBtn?.addEventListener('click', () => openDropdown('guests'));

  document.getElementById('apply-dates-btn')?.addEventListener('click', () => openDropdown('guests'));
  document.getElementById('apply-guests-btn')?.addEventListener('click', () => {
    syncGuestText();
    dropdown?.classList.remove('is-open');
  });

  dropdown?.querySelectorAll('[data-step]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const key = btn.dataset.step;
      const delta = Number(btn.dataset.delta);
      const minVal = key === 'adults' || key === 'rooms' ? 1 : 0;
      counts[key] = Math.max(minVal, counts[key] + delta);
      syncGuestText();
    });
  });

  form?.addEventListener('submit', (e) => {
    e.preventDefault();
    const destVal = (destInput?.value || '').trim();
    if (!destVal) {
      if (errorBox) errorBox.textContent = 'Please enter a destination before searching stays.';
      openDropdown('destination');
      destInput?.focus();
      return;
    }

    const updatedRecent = [destVal, ...(searchState.recentDestinations || []).filter((x) => x.toLowerCase() !== destVal.toLowerCase())].slice(0, 4);
    const nextSearch = {
      destination: destVal,
      checkIn: checkInInput?.value || '2026-12-12',
      checkOut: checkOutInput?.value || '2026-12-15',
      adults: counts.adults,
      children: counts.children,
      rooms: counts.rooms,
      recentDestinations: updatedRecent
    };
    writeStorage(EL_STORAGE_KEYS.SEARCH, nextSearch);
    window.location.href = routePath('search-results');
  });

  syncGuestText();
  renderDestinationChips();

  // Populate Featured Destinations & Trending Lodgings
  const hotels = getAllHotels(true);
  const featuredContainer = document.getElementById('featured-destinations-grid');
  if (featuredContainer) {
    featuredContainer.innerHTML = EL_SEED_DATA.cities
      .map(
        (city) => `
      <a href="${routePath('search-results')}?city=${encodeURIComponent(city.name)}" class="hotel-card" data-reveal-card>
        <div class="hotel-card__media">
          <img src="${city.homeImage}" alt="${city.name} luxury stays" />
        </div>
        <div class="hotel-card__body">
          <span class="badge badge--gold">${city.region}</span>
          <h3 style="margin:0;font-family:var(--font-serif);font-size:1.15rem;">${city.name}</h3>
          <div class="price-tag">From ${formatPkr(city.startingPrice)} <span>/ night · ${city.staysCount} stays</span></div>
        </div>
      </a>
    `
      )
      .join('');
  }

  const trendingContainer = document.getElementById('trending-lodgings-grid');
  if (trendingContainer) {
    trendingContainer.innerHTML = hotels
      .slice(0, 4)
      .map(
        (hotel) => `
      <article class="hotel-card">
        <div class="hotel-card__media">
          <img src="${hotel.resolvedImages[0]}" alt="${hotel.name} in ${hotel.city}" />
        </div>
        <div class="hotel-card__body">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:0.5rem;">
            <span class="badge">${hotel.city}</span>
            <span style="font-size:0.84rem;font-weight:700;color:var(--gold-hover);">★ ${hotel.ratingScore}</span>
          </div>
          <h3 style="margin:0;font-family:var(--font-serif);font-size:1.15rem;">${hotel.name}</h3>
          <div style="display:flex;align-items:center;justify-content:space-between;margin-top:auto;padding-top:0.5rem;">
            <div class="price-tag">${formatPkr(hotel.pricePerNight)} <span>/ night</span></div>
            <a href="${routePath('property-details')}?id=${encodeURIComponent(hotel.id)}" class="btn btn--primary btn--sm">View Stay</a>
          </div>
        </div>
      </article>
    `
      )
      .join('');
  }
}

function initExploreCitiesPage() {
  ensureSeededState();
  let selectedRegion = 'All Cities';
  let queryText = '';

  const pillsWrap = document.getElementById('region-filter-pills');
  const searchInput = document.getElementById('city-search-input');
  const grid = document.getElementById('explore-cities-grid');

  const regions = ['All Cities', 'Northern Valleys', 'Urban Hubs', 'Heritage Centers'];
  if (pillsWrap) {
    pillsWrap.innerHTML = regions
      .map(
        (r) => `<button type="button" class="filter-chip ${r === selectedRegion ? 'is-active' : ''}" data-region="${r}">${r}</button>`
      )
      .join('');

    pillsWrap.querySelectorAll('[data-region]').forEach((btn) => {
      btn.addEventListener('click', () => {
        selectedRegion = btn.dataset.region;
        pillsWrap.querySelectorAll('[data-region]').forEach((b) => b.classList.toggle('is-active', b === btn));
        renderCities();
      });
    });
  }

  searchInput?.addEventListener('input', (e) => {
    queryText = e.target.value.trim().toLowerCase();
    renderCities();
  });

  function renderCities() {
    if (!grid) return;
    const filtered = EL_SEED_DATA.cities.filter((c) => {
      const regionMatch = selectedRegion === 'All Cities' || c.region === selectedRegion;
      const textMatch = !queryText || c.name.toLowerCase().includes(queryText) || c.region.toLowerCase().includes(queryText);
      return regionMatch && textMatch;
    });

    if (!filtered.length) {
      grid.innerHTML = `<div class="card" style="padding:2rem;grid-column:1/-1;text-align:center;">
        <p style="margin:0 0 0.75rem;font-weight:600;">No cities match "${queryText}".</p>
        <button type="button" class="btn btn--outline btn--sm" id="reset-city-filters">Reset Filters</button>
      </div>`;
      document.getElementById('reset-city-filters')?.addEventListener('click', () => {
        selectedRegion = 'All Cities';
        queryText = '';
        if (searchInput) searchInput.value = '';
        pillsWrap?.querySelectorAll('[data-region]').forEach((b, idx) => b.classList.toggle('is-active', idx === 0));
        renderCities();
      });
      return;
    }

    grid.innerHTML = filtered
      .map(
        (c) => `
      <a href="${routePath('search-results')}?city=${encodeURIComponent(c.name)}" class="city-card" data-select-city="${c.name}">
        <div class="city-card__img-wrap">
          <img src="${c.image}" alt="${c.name} luxury hotels" />
        </div>
        <div class="city-card__body">
          <span class="badge badge--gold" style="margin-bottom:0.4rem;">${c.region}</span>
          <h3 style="margin:0 0 0.25rem;font-family:var(--font-serif);font-size:1.2rem;">${c.name}</h3>
          <p style="margin:0 0 0.65rem;font-size:0.84rem;color:var(--ink-secondary);">${c.tagline}</p>
          <div class="price-tag">${c.staysCount} stays · From ${formatPkr(c.startingPrice)} <span>/ night</span></div>
        </div>
      </a>
    `
      )
      .join('');

    grid.querySelectorAll('[data-select-city]').forEach((card) => {
      card.addEventListener('click', () => {
        const s = readStorage(EL_STORAGE_KEYS.SEARCH, EL_SEED_DATA.defaultSearch);
        s.destination = card.dataset.selectCity;
        writeStorage(EL_STORAGE_KEYS.SEARCH, s);
      });
    });
  }

  renderCities();
}

function initSearchResultsPage() {
  ensureSeededState();
  const params = new URLSearchParams(window.location.search);
  const urlCity = params.get('city');
  const searchState = readStorage(EL_STORAGE_KEYS.SEARCH, EL_SEED_DATA.defaultSearch);

  let activeCity = urlCity || searchState.destination || 'All';
  if (urlCity) {
    searchState.destination = urlCity;
    writeStorage(EL_STORAGE_KEYS.SEARCH, searchState);
  }

  let maxPrice = 60000;
  let minStars = 0;
  let selectedAmenities = [];
  let sortBy = 'recommended';
  let viewMode = 'list';

  const summaryEl = document.getElementById('search-context-summary');
  const countEl = document.getElementById('results-count-label');
  const listWrap = document.getElementById('search-results-list');
  const mapWrap = document.getElementById('search-map-view');
  const priceRange = document.getElementById('price-range-input');
  const priceDisplay = document.getElementById('price-range-display');
  const sortSelect = document.getElementById('results-sort-select');

  if (summaryEl) {
    const nights = calculateNights(searchState.checkIn, searchState.checkOut);
    summaryEl.textContent = `${activeCity} · ${searchState.checkIn} to ${searchState.checkOut} (${nights} ${nights === 1 ? 'night' : 'nights'}) · ${(searchState.adults || 2) + (searchState.children || 0)} guests`;
  }

  priceRange?.addEventListener('input', (e) => {
    maxPrice = Number(e.target.value);
    if (priceDisplay) priceDisplay.textContent = `Up to ${formatPkr(maxPrice)} / night`;
    renderResults();
  });

  document.querySelectorAll('[data-star-filter]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const val = Number(btn.dataset.starFilter);
      minStars = minStars === val ? 0 : val;
      document.querySelectorAll('[data-star-filter]').forEach((b) => b.classList.toggle('is-active', Number(b.dataset.starFilter) === minStars && minStars > 0));
      renderResults();
    });
  });

  document.querySelectorAll('[data-amenity-filter]').forEach((cb) => {
    cb.addEventListener('change', () => {
      selectedAmenities = Array.from(document.querySelectorAll('[data-amenity-filter]:checked')).map((i) => i.value);
      renderResults();
    });
  });

  sortSelect?.addEventListener('change', (e) => {
    sortBy = e.target.value;
    renderResults();
  });

  document.getElementById('view-list-btn')?.addEventListener('click', () => {
    viewMode = 'list';
    document.getElementById('view-list-btn').classList.add('is-active');
    document.getElementById('view-map-btn')?.classList.remove('is-active');
    if (listWrap) listWrap.style.display = 'grid';
    if (mapWrap) mapWrap.style.display = 'none';
  });

  document.getElementById('view-map-btn')?.addEventListener('click', () => {
    viewMode = 'map';
    document.getElementById('view-map-btn').classList.add('is-active');
    document.getElementById('view-list-btn')?.classList.remove('is-active');
    if (listWrap) listWrap.style.display = 'none';
    if (mapWrap) mapWrap.style.display = 'block';
    renderMapPins();
  });

  document.getElementById('clear-all-filters-btn')?.addEventListener('click', () => {
    activeCity = 'All';
    maxPrice = 60000;
    minStars = 0;
    selectedAmenities = [];
    if (priceRange) priceRange.value = 60000;
    if (priceDisplay) priceDisplay.textContent = `Up to ${formatPkr(60000)} / night`;
    document.querySelectorAll('[data-star-filter]').forEach((b) => b.classList.remove('is-active'));
    document.querySelectorAll('[data-amenity-filter]').forEach((c) => { c.checked = false; });
    renderResults();
  });

  function getFilteredHotels() {
    const all = getAllHotels(false);
    let items = all.filter((h) => {
      const cityMatch =
        !activeCity ||
        activeCity === 'All' ||
        h.city.toLowerCase().includes(activeCity.toLowerCase()) ||
        h.name.toLowerCase().includes(activeCity.toLowerCase()) ||
        h.region.toLowerCase().includes(activeCity.toLowerCase());
      const priceMatch = h.pricePerNight <= maxPrice;
      const starMatch = minStars === 0 || h.starRating >= minStars;
      const amenityMatch = selectedAmenities.every((am) => h.amenities.includes(am));
      return cityMatch && priceMatch && starMatch && amenityMatch;
    });

    if (sortBy === 'price-asc') items.sort((a, b) => a.pricePerNight - b.pricePerNight);
    if (sortBy === 'price-desc') items.sort((a, b) => b.pricePerNight - a.pricePerNight);
    if (sortBy === 'rating-desc') items.sort((a, b) => b.ratingScore - a.ratingScore);
    return items;
  }

  function renderMapPins() {
    if (!mapWrap) return;
    const items = getFilteredHotels();
    mapWrap.innerHTML = `
      <div class="card" style="padding:1.5rem;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;">
          <h3 style="margin:0;font-family:var(--font-serif);">Destination Map Overview (${items.length} stays)</h3>
          <span class="badge badge--gold">Interactive Directory</span>
        </div>
        <div class="grid-2">
          ${items
            .map(
              (h) => `
            <div style="border:1px solid var(--border-subtle);border-radius:var(--radius-sm);padding:1rem;background:var(--bg-ivory);">
              <div style="font-weight:700;">📍 ${h.name}</div>
              <div style="font-size:0.85rem;color:var(--ink-secondary);margin:0.25rem 0;">${h.area} · ${h.city}</div>
              <div style="display:flex;justify-content:space-between;align-items:center;margin-top:0.65rem;">
                <span class="price-tag">${formatPkr(h.pricePerNight)} <span>/ night</span></span>
                <a href="${routePath('property-details')}?id=${encodeURIComponent(h.id)}" class="btn btn--primary btn--sm">View</a>
              </div>
            </div>
          `
            )
            .join('')}
        </div>
      </div>
    `;
  }

  function renderResults() {
    const items = getFilteredHotels();
    if (countEl) countEl.textContent = `${items.length} ${items.length === 1 ? 'stay' : 'stays'} found`;

    if (!listWrap) return;
    if (!items.length) {
      listWrap.innerHTML = `
        <div class="card" style="padding:2.25rem;text-align:center;">
          <h3 style="margin:0 0 0.5rem;font-family:var(--font-serif);">No matching luxury stays found</h3>
          <p class="section-subtitle" style="margin-bottom:1rem;">Try raising your maximum PKR budget or clearing an amenity filter.</p>
          <button type="button" class="btn btn--primary btn--sm" id="empty-reset-btn">Show All Stays</button>
        </div>
      `;
      document.getElementById('empty-reset-btn')?.addEventListener('click', () => {
        document.getElementById('clear-all-filters-btn')?.click();
      });
      return;
    }

    listWrap.style.display = viewMode === 'list' ? 'grid' : 'none';
    listWrap.style.gap = '1.15rem';
    listWrap.innerHTML = items
      .map(
        (h) => `
      <article class="result-card">
        <div style="overflow:hidden;">
          <img src="${h.resolvedImages[0]}" alt="${h.name}" class="result-card__img" />
        </div>
        <div style="padding:1.2rem 1.35rem;display:flex;flex-direction:column;justify-content:space-between;gap:0.75rem;">
          <div>
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:0.75rem;flex-wrap:wrap;">
              <div>
                <h3 style="margin:0;font-family:var(--font-serif);font-size:1.25rem;">${h.name}</h3>
                <div style="font-size:0.86rem;color:var(--ink-secondary);">${h.area} · ${h.city}</div>
              </div>
              <span class="badge badge--gold">★ ${h.ratingScore} (${h.reviewCount} reviews)</span>
            </div>
            <div style="display:flex;flex-wrap:wrap;gap:0.4rem;margin-top:0.75rem;">
              ${h.amenities.slice(0, 4).map((am) => `<span class="badge">${am}</span>`).join('')}
            </div>
          </div>

          <div style="display:flex;align-items:center;justify-content:space-between;gap:1rem;padding-top:0.65rem;border-top:1px solid var(--border-subtle);flex-wrap:wrap;">
            <div>
              <div class="price-tag">${formatPkr(h.pricePerNight)} <span>/ night</span></div>
              <div style="font-size:0.78rem;color:var(--ink-muted);">${h.freeCancellation ? 'Free cancellation available' : 'Standard rate'}</div>
            </div>
            <a href="${routePath('property-details')}?id=${encodeURIComponent(h.id)}" class="btn btn--primary btn--sm">View</a>
          </div>
        </div>
      </article>
    `
      )
      .join('');
  }

  renderResults();
}
