const EL_STORAGE_KEYS = {
  SEARCH: 'el_search_state_v21',
  BOOKING_DRAFT: 'el_booking_draft_v21',
  BOOKINGS: 'el_bookings_list_v21',
  SAVED_IDS: 'el_saved_stays_v21',
  PROFILE: 'el_traveler_profile_v21',
  REVIEWS: 'el_reviews_list_v21',
  HOST_LISTINGS: 'el_host_listings_v21'
};

const EL_SEED_DATA = {
  cities: [
    {
      id: 'islamabad',
      name: 'Islamabad',
      region: 'Urban Hubs',
      staysCount: 18,
      startingPrice: 24000,
      tagline: 'Margalla foothills, diplomatic calm & refined suites',
      image: '../images/frames-for-your-heart-zSG-kd-L6vw-unsplash.jpg',
      homeImage: 'images/frames-for-your-heart-zSG-kd-L6vw-unsplash.jpg'
    },
    {
      id: 'hunza',
      name: 'Hunza Valley',
      region: 'Northern Valleys',
      staysCount: 14,
      startingPrice: 28000,
      tagline: 'Glacier peaks, apricot terraces & mountain sanctuaries',
      image: '../images/hero-mountain-sanctuary.jpg',
      homeImage: 'images/hero-mountain-sanctuary.jpg'
    },
    {
      id: 'skardu',
      name: 'Skardu',
      region: 'Northern Valleys',
      staysCount: 11,
      startingPrice: 32000,
      tagline: 'High-altitude serenity beside turquoise alpine lakes',
      image: '../images/pool-courtyard-retreat.jpg',
      homeImage: 'images/pool-courtyard-retreat.jpg'
    },
    {
      id: 'lahore',
      name: 'Lahore',
      region: 'Heritage Centers',
      staysCount: 22,
      startingPrice: 21000,
      tagline: 'Mughal courtyards, grand arches & royal hospitality',
      image: '../images/heritage-palace-arch.jpg',
      homeImage: 'images/heritage-palace-arch.jpg'
    }
  ],

  hotels: [
    {
      id: 'margalla-crest-palace',
      name: 'The Margalla Crest Palace',
      city: 'Islamabad',
      area: 'Sector E-7, Margalla View',
      region: 'Urban Hubs',
      starRating: 5,
      ratingScore: 4.9,
      reviewCount: 318,
      pricePerNight: 36000,
      trending: true,
      featured: true,
      freeCancellation: true,
      amenities: ['Wi-Fi', 'Parking', 'Pool', 'Breakfast', 'AC', 'Laundry'],
      description: 'Set against the forested slopes of Margalla Hills, The Margalla Crest Palace pairs warm walnut paneling, limestone terraces, and private heated plunge pools with attentive concierge service.',
      images: [
        '../images/frames-for-your-heart-zSG-kd-L6vw-unsplash.jpg',
        '../images/suite-penthouse-view.jpg',
        '../images/pool-courtyard-retreat.jpg',
        '../images/rod-long-2P_ifaetDm0-unsplash.jpg'
      ],
      homeImages: [
        'images/frames-for-your-heart-zSG-kd-L6vw-unsplash.jpg',
        'images/suite-penthouse-view.jpg'
      ],
      rooms: [
        { id: 'deluxe-king', name: 'Deluxe Courtyard King', capacity: 2, bedType: '1 King Bed', rateMultiplier: 1.0 },
        { id: 'executive-suite', name: 'Margalla Panorama Suite', capacity: 3, bedType: '1 King + Lounge', rateMultiplier: 1.45 },
        { id: 'royal-residence', name: 'Diplomatic Penthouse Suite', capacity: 4, bedType: '2 King Beds', rateMultiplier: 2.0 }
      ]
    },
    {
      id: 'eagle-nest-hunza',
      name: 'Eagle Nest Sanctuary Hunza',
      city: 'Hunza Valley',
      area: 'Duikar Ridge, Karimabad',
      region: 'Northern Valleys',
      starRating: 5,
      ratingScore: 4.9,
      reviewCount: 204,
      pricePerNight: 34000,
      trending: true,
      featured: true,
      freeCancellation: true,
      amenities: ['Wi-Fi', 'Parking', 'Breakfast', 'Laundry'],
      description: 'Perched above Hunza with uninterrupted views of Rakaposhi and Ultar Sar, offering cedar-lined suites, hearth dining, and guided valley walks.',
      images: [
        '../images/hero-mountain-sanctuary.jpg',
        '../images/rod-long-2P_ifaetDm0-unsplash.jpg',
        '../images/suite-penthouse-view.jpg',
        '../images/frames-for-your-heart-zSG-kd-L6vw-unsplash.jpg'
      ],
      homeImages: [
        'images/hero-mountain-sanctuary.jpg',
        'images/rod-long-2P_ifaetDm0-unsplash.jpg'
      ],
      rooms: [
        { id: 'ridge-room', name: 'Peak View Cedar Room', capacity: 2, bedType: '1 Queen Bed', rateMultiplier: 1.0 },
        { id: 'valley-suite', name: 'Glacier Terrace Suite', capacity: 3, bedType: '1 King Bed', rateMultiplier: 1.38 },
        { id: 'family-lodge', name: 'Hunza Heritage Chalet', capacity: 4, bedType: '2 Queen Beds', rateMultiplier: 1.8 }
      ]
    },
    {
      id: 'kachura-horizon-lodge',
      name: 'Kachura Horizon Lodge',
      city: 'Skardu',
      area: 'Lower Kachura Lakefront',
      region: 'Northern Valleys',
      starRating: 4,
      ratingScore: 4.8,
      reviewCount: 156,
      pricePerNight: 32000,
      trending: true,
      featured: true,
      freeCancellation: true,
      amenities: ['Wi-Fi', 'Parking', 'Breakfast', 'AC'],
      description: 'A tranquil alpine retreat beside still waters and towering granite peaks, featuring timber-framed rooms, stargazing decks, and freshly baked mountain breakfasts.',
      images: [
        '../images/pool-courtyard-retreat.jpg',
        '../images/hero-mountain-sanctuary.jpg',
        '../images/rod-long-2P_ifaetDm0-unsplash.jpg',
        '../images/frames-for-your-heart-zSG-kd-L6vw-unsplash.jpg'
      ],
      homeImages: [
        'images/pool-courtyard-retreat.jpg',
        'images/hero-mountain-sanctuary.jpg'
      ],
      rooms: [
        { id: 'lake-deluxe', name: 'Lakefront Deluxe Room', capacity: 2, bedType: '1 King Bed', rateMultiplier: 1.0 },
        { id: 'alpine-suite', name: 'Karakoram Junior Suite', capacity: 3, bedType: '1 King + Sofa Bed', rateMultiplier: 1.4 },
        { id: 'summit-villa', name: 'Lakeview Private Villa', capacity: 4, bedType: '2 King Beds', rateMultiplier: 1.85 }
      ]
    },
    {
      id: 'qasr-e-gul-heritage',
      name: 'Qasr-e-Gul Heritage Hotel',
      city: 'Lahore',
      area: 'Gulberg III, Heritage Lane',
      region: 'Heritage Centers',
      starRating: 5,
      ratingScore: 4.8,
      reviewCount: 275,
      pricePerNight: 27000,
      trending: true,
      featured: true,
      freeCancellation: false,
      amenities: ['Wi-Fi', 'Parking', 'Pool', 'Breakfast', 'AC', 'Laundry'],
      description: 'Inspired by classical Lahore architecture with arched verandas, brass lanterns, landscaped gardens, and a serene courtyard pool.',
      images: [
        '../images/heritage-palace-arch.jpg',
        '../images/rod-long-2P_ifaetDm0-unsplash.jpg',
        '../images/pool-courtyard-retreat.jpg',
        '../images/frames-for-your-heart-zSG-kd-L6vw-unsplash.jpg'
      ],
      homeImages: [
        'images/heritage-palace-arch.jpg',
        '../images/rod-long-2P_ifaetDm0-unsplash.jpg'
      ],
      rooms: [
        { id: 'courtyard-king', name: 'Courtyard Arch Room', capacity: 2, bedType: '1 King Bed', rateMultiplier: 1.0 },
        { id: 'mughal-suite', name: 'Baradari Royal Suite', capacity: 3, bedType: '1 King Bed', rateMultiplier: 1.5 },
        { id: 'nawab-suite', name: 'Grand Heritage Suite', capacity: 4, bedType: '2 King Beds', rateMultiplier: 2.1 }
      ]
    }
  ],

  addons: [
    { id: 'airport-pickup', label: 'Airport Pickup', pricePkr: 4500, description: 'Private chauffeur sedan transfer' },
    { id: 'extra-bed', label: 'Extra Bed', pricePkr: 3500, description: 'Luxury rollaway bed & linens per stay' }
  ],

  defaultSearch: {
    destination: 'Islamabad',
    checkIn: '2026-12-12',
    checkOut: '2026-12-15',
    adults: 2,
    children: 0,
    rooms: 1,
    recentDestinations: ['Islamabad', 'Hunza Valley', 'Lahore']
  },

  defaultBookings: [
    {
      ref: 'EL-90514',
      hotelId: 'margalla-crest-palace',
      hotelName: 'The Margalla Crest Palace',
      city: 'Islamabad',
      roomName: 'Margalla Panorama Suite',
      roomPricePerNight: 52200,
      checkIn: '2026-12-12',
      checkOut: '2026-12-15',
      nights: 3,
      guests: 2,
      addons: [{ id: 'airport-pickup', label: 'Airport Pickup', pricePkr: 4500 }],
      totalPkr: 161100,
      paymentMethod: 'Pay at Property',
      guestName: 'Ayesha Siddiqui',
      guestEmail: 'ayesha.siddiqui@example.pk',
      guestPhone: '+92 300 5550194',
      status: 'Upcoming'
    },
    {
      ref: 'EL-88412',
      hotelId: 'eagle-nest-hunza',
      hotelName: 'Eagle Nest Sanctuary Hunza',
      city: 'Hunza Valley',
      roomName: 'Peak View Cedar Room',
      roomPricePerNight: 34000,
      checkIn: '2026-08-10',
      checkOut: '2026-08-12',
      nights: 2,
      guests: 2,
      addons: [],
      totalPkr: 68000,
      paymentMethod: 'Card / Transfer',
      guestName: 'Ayesha Siddiqui',
      guestEmail: 'ayesha.siddiqui@example.pk',
      guestPhone: '+92 300 5550194',
      status: 'Past'
    }
  ],

  defaultProfile: {
    signedIn: true,
    fullName: 'Ayesha Siddiqui',
    email: 'ayesha.siddiqui@example.pk',
    phone: '+92 300 5550194',
    memberSince: 'March 2025',
    currency: 'PKR',
    roomPreference: 'King Bed — Quiet High Floor'
  },

  defaultReviews: [
    {
      id: 'rev-1',
      guestName: 'Bilal Mahmood',
      rating: 5,
      monthYear: 'October 2026',
      comment: 'Quiet suites, thoughtful hospitality, and effortless check-in in Islamabad. Breakfast on the terrace was memorable.'
    },
    {
      id: 'rev-2',
      guestName: 'Zainab Tariq',
      rating: 5,
      monthYear: 'September 2026',
      comment: 'Transparent PKR pricing with zero surprises at checkout. Our mountain stay in Hunza felt calm and well cared for.'
    },
    {
      id: 'rev-3',
      guestName: 'Hamza Raza',
      rating: 4,
      monthYear: 'August 2026',
      comment: 'Spacious rooms, clean pools, and prompt airport pickup coordination.'
    }
  ],

  defaultHostListings: [
    {
      id: 'host-1',
      name: 'The Margalla Crest Palace',
      city: 'Islamabad, Sector E-7',
      category: 'Luxury Hotel',
      nightlyPkr: 36000,
      status: 'Active',
      upcomingNights: 18,
      rating: 4.9,
      amenities: ['Wi-Fi', 'Parking', 'Pool', 'Breakfast', 'AC', 'Laundry'],
      image: '../images/frames-for-your-heart-zSG-kd-L6vw-unsplash.jpg'
    },
    {
      id: 'host-2',
      name: 'Eagle Nest Sanctuary Hunza',
      city: 'Hunza Valley, Duikar',
      category: 'Mountain Resort',
      nightlyPkr: 34000,
      status: 'Active',
      upcomingNights: 12,
      rating: 4.9,
      amenities: ['Wi-Fi', 'Parking', 'Breakfast', 'Laundry'],
      image: '../images/hero-mountain-sanctuary.jpg'
    },
    {
      id: 'host-3',
      name: 'Qasr-e-Gul Heritage Hotel',
      city: 'Lahore, Gulberg III',
      category: 'Heritage Boutique',
      nightlyPkr: 27000,
      status: 'Paused',
      upcomingNights: 6,
      rating: 4.8,
      amenities: ['Wi-Fi', 'Parking', 'Pool', 'Breakfast', 'AC'],
      image: '../images/heritage-palace-arch.jpg'
    }
  ]
};

function readStorage(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return structuredClone(fallback);
    return JSON.parse(raw);
  } catch (err) {
    return structuredClone(fallback);
  }
}

function writeStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    // Ignore storage quota errors in restricted environments
  }
}

function ensureSeededState() {
  if (!localStorage.getItem(EL_STORAGE_KEYS.SEARCH)) {
    writeStorage(EL_STORAGE_KEYS.SEARCH, EL_SEED_DATA.defaultSearch);
  }
  if (!localStorage.getItem(EL_STORAGE_KEYS.BOOKINGS)) {
    writeStorage(EL_STORAGE_KEYS.BOOKINGS, EL_SEED_DATA.defaultBookings);
  }
  if (!localStorage.getItem(EL_STORAGE_KEYS.SAVED_IDS)) {
    writeStorage(EL_STORAGE_KEYS.SAVED_IDS, ['margalla-crest-palace', 'eagle-nest-hunza']);
  }
  if (!localStorage.getItem(EL_STORAGE_KEYS.PROFILE)) {
    writeStorage(EL_STORAGE_KEYS.PROFILE, EL_SEED_DATA.defaultProfile);
  }
  if (!localStorage.getItem(EL_STORAGE_KEYS.REVIEWS)) {
    writeStorage(EL_STORAGE_KEYS.REVIEWS, EL_SEED_DATA.defaultReviews);
  }
  if (!localStorage.getItem(EL_STORAGE_KEYS.HOST_LISTINGS)) {
    writeStorage(EL_STORAGE_KEYS.HOST_LISTINGS, EL_SEED_DATA.defaultHostListings);
  }
}

function getAllHotels(isRootPage = false) {
  ensureSeededState();
  const hostListings = readStorage(EL_STORAGE_KEYS.HOST_LISTINGS, []);
  const activeCustom = hostListings
    .filter((item) => item.status === 'Active' && !EL_SEED_DATA.hotels.some((h) => h.name === item.name))
    .map((item, idx) => ({
      id: item.id || `custom-${idx}`,
      name: item.name,
      city: item.city.split(',')[0].trim() || 'Islamabad',
      area: item.city,
      region: 'Urban Hubs',
      starRating: 5,
      ratingScore: Number(item.rating || 4.8),
      reviewCount: 42,
      pricePerNight: Number(item.nightlyPkr || 25000),
      trending: true,
      featured: false,
      freeCancellation: true,
      amenities: item.amenities && item.amenities.length ? item.amenities : ['Wi-Fi', 'Breakfast'],
      description: `${item.category || 'Luxury Stay'} in ${item.city}, curated on EasyLodging with transparent PKR rates.`,
      images: [
        item.image || '../images/frames-for-your-heart-zSG-kd-L6vw-unsplash.jpg',
        '../images/suite-penthouse-view.jpg',
        '../images/pool-courtyard-retreat.jpg',
        '../images/rod-long-2P_ifaetDm0-unsplash.jpg'
      ],
      homeImages: [
        'images/frames-for-your-heart-zSG-kd-L6vw-unsplash.jpg',
        'images/suite-penthouse-view.jpg'
      ],
      rooms: [
        { id: 'standard-king', name: 'Deluxe Suite', capacity: 2, bedType: '1 King Bed', rateMultiplier: 1.0 },
        { id: 'grand-suite', name: 'Executive Suite', capacity: 4, bedType: '2 King Beds', rateMultiplier: 1.5 }
      ]
    }));

  return [...EL_SEED_DATA.hotels, ...activeCustom].map((hotel) => ({
    ...hotel,
    resolvedImages: isRootPage ? hotel.homeImages : hotel.images
  }));
}

function formatPkr(amount) {
  const numeric = Number(amount) || 0;
  return `PKR ${numeric.toLocaleString('en-PK')}`;
}

function calculateNights(checkInStr, checkOutStr) {
  if (!checkInStr || !checkOutStr) return 1;
  const start = new Date(`${checkInStr}T00:00:00`);
  const end = new Date(`${checkOutStr}T00:00:00`);
  const days = Math.round((end - start) / (1000 * 60 * 60 * 24));
  return days > 0 ? days : 1;
}
