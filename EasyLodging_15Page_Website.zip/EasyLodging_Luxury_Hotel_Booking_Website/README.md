# EasyLodging — Luxury Hotel Booking Website

## Theme
Hotel Booking (Travel & Hospitality) · Currency: **PKR**

## Project Structure
- `index.html` — Page 1: Home Page
- `pages/` — Pages 2 through 15 (`explore-cities.html`, `search-results.html`, `property-details.html`, `rooms-addons.html`, `checkout.html`, `booking-confirmation.html`, `my-bookings.html`, `modify-cancel.html`, `saved-stays.html`, `traveler-profile.html`, `reviews-ratings.html`, `host-dashboard.html`, `add-edit-listing.html`, `help-center.html`)
- `css/` — `style.css`, `pages.css`, `responsive.css`
- `js/` — `storage.js`, `main.js`, `search.js`, `booking.js`, `pages.js`
- `images/` — Hotel & architectural imagery
- `docs/` — `image-sources.md`, `project-notes.md`

## Running Locally
1. Extract `EasyLodging_Luxury_Hotel_Booking_Website.zip`.
2. Serve the folder with any local static server (for example `python -m http.server 8080` inside the project directory) and open `http://localhost:8080/index.html`.
