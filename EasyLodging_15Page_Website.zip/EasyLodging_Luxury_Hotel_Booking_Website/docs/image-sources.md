# EasyLodging — Image Sources & Disclosures

## Included Assets in `images/`
1. `frames-for-your-heart-zSG-kd-L6vw-unsplash.jpg` — Unsplash interior photography (Frames For Your Heart).
2. `rod-long-2P_ifaetDm0-unsplash.jpg` — Unsplash interior photography (Rod Long).
3. `hero-mountain-sanctuary.jpg` — Generated luxury alpine sanctuary visual created via Python/Pillow for EasyLodging.
4. `pool-courtyard-retreat.jpg` — Generated luxury pool & courtyard visual created via Python/Pillow for EasyLodging.
5. `suite-penthouse-view.jpg` — Generated luxury suite architectural visual created via Python/Pillow for EasyLodging.
6. `heritage-palace-arch.jpg` — Generated heritage courtyard visual created via Python/Pillow for EasyLodging.

## Demo & Disclosure Note
- All property prices (in PKR), reviews, profiles, and bookings are simulated in `localStorage` for demonstration purposes.
- No third-party hotel brand endorsements are implied.
