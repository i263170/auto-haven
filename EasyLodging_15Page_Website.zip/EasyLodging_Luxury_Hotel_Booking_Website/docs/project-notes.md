# EasyLodging — Implementation Notes (v2.1)

- **Viewports:** Styled for Desktop (1440px) and Mobile (375px / <=768px) using HTML5, CSS3, and Vanilla JavaScript.
- **Persistence:** Uses `localStorage` keys prefixed with `el_*_v21` across search, booking draft, bookings list, saved stays, traveler profile (including guest sign-in status), reviews, and host listings.
- **Animations:** Includes slow hero zoom, card hover lift, gentle image zoom, gold button hover/scale, page entrance transitions, nav underline hover, lightbox image transitions, search dropdown transitions, animated step indicators, confirmation badge animation, mobile sticky bar slide-in, and scroll reveal (`prefers-reduced-motion` respected).
